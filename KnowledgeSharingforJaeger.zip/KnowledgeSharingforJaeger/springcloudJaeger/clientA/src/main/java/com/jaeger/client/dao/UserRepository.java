package com.jaeger.client.dao;


import com.jaeger.client.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @ Author     ：LYH.
 * @ Date       ：Created in 19:27 2020/7/4
 */
public interface UserRepository extends JpaRepository<User,Long> {

    User findByName(String userName);

}
