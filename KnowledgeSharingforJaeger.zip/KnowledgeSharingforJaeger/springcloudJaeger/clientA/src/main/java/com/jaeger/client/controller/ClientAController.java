package com.jaeger.client.controller;

import com.jaeger.client.dao.UserRepository;
import com.jaeger.client.domain.User;
import com.jaeger.client.feign.ClientB;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@Slf4j
@RestController
public class ClientAController {
    @Autowired
    ClientB clientB;
    @Autowired
    private UserRepository userRepository;

    @RequestMapping(value = "clineta", method = RequestMethod.GET)
    public String jaegerTest() throws InterruptedException {

        log.info("Client A Starts.");
        Thread.sleep(200);
        return clientB.clientB("Client_A");
    }

    @RequestMapping(value = "jdbcTest", method = RequestMethod.POST)
    public String jdbcTest() {
        User user = new User();
        user.setId(1L);
        user.setName("Jacky");
        User save = userRepository.save(user);
        return "succeed";
    }



//    @Autowired
//    private RestTemplate restTemplate;

//    @RequestMapping("/tracing_a")
//    public String open() throws InterruptedException {
//
//        log.info("tracing_a start!");
//        String url = "http://localhost:8082" + "/tracing_b";
//        System.out.println(url);
//        Thread.sleep(500);
//        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
//        return "tracing_a " + response.getBody();
//
//    }

}
