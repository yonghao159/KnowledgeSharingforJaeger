package com.jaeger.client.controller;

import com.jaeger.client.feign.ClientC;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class ClientBController {

    @Autowired
    ClientC clientC;

    @RequestMapping(value = "clientb", method = RequestMethod.POST)
    public String clientB(@RequestParam("clientName")  String clientName) throws InterruptedException {

        log.info("client B .");
        Thread.sleep(200);
        return "Client_B:"+clientC.clientC(clientName);
    }


}
