package com.jaeger.client.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class ControllerClientC {

    @RequestMapping(value = "clientc", method = RequestMethod.POST)
    public String clientB(@RequestParam("clientName")  String clientName) throws InterruptedException {

        log.info("client C ." );
        Thread.sleep(3000);
        return "Client_C:"+clientName;
    }


}
